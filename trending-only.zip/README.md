# TrendingOnly

TrendingOnly is a dynamic platform dedicated to providing the latest articles and breaking news across various categories. Inspired by major news websites like detik.com, our goal is to keep readers updated with trending content in real-time.

## Features

- **Article Categories**: Browse articles across different categories like technology, sports, entertainment, politics, and more.
- **Trending News**: Stay up-to-date with the latest trending stories and headlines.

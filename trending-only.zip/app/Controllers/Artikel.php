<?php

namespace App\Controllers;

use App\Models\ArtikelModel;
use App\Models\KategoriModel;

class Artikel extends BaseController
{
    protected $artikelModel;
    protected $kategoriModel;

    public function __construct()
    {
        $this->artikelModel = new ArtikelModel();
        $this->kategoriModel = new KategoriModel();
    }

    public function kategori($kategoriSlug)
    {

        $categories = $this->kategoriModel->get_categories_with_thumbnails();


        $kategoris = $this->kategoriModel->findAll();
        $kategori = $this->kategoriModel->getBySlug($kategoriSlug);
        if (!$kategori) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Kategori tidak ditemukan');
        }

        $artikels = $this->artikelModel->getByKategori($kategori['id_kategori']);

        $kategoriWithCount = [];
        foreach ($kategoris as $kg) {
            $count = $this->artikelModel->where('id_kategori', $kg['id_kategori'])->countAllResults();
            $kategoriWithCount[] = [
                'kategori' => $kg,
                'count' => $count
            ];


            // $artikel = $this->artikelModel->getLatestByKategori($kategori['id_kategori'], 3);
            // $kategoriArtikel[] = [
            //     'kategori' => $kategori,
            //     'artikels' => $artikel
            // ];
        }

        $data = [
            'kategori' => $kategori,
            'artikels' => $artikels,
            'categories' => $categories,
            'allKategoris' => $kategoriWithCount
        ];

        return view('artikel/kategori', $data);
    }

    public function detail($kategoriSlug, $artikelSlug)
    {
        $kategoris = $this->kategoriModel->findAll();
        $kategori = $this->kategoriModel->getBySlug($kategoriSlug);
        if (!$kategori) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Kategori tidak ditemukan');
        }

        $artikel = $this->artikelModel->getDetailArtikel($artikelSlug, $kategori['id_kategori']);
        if (!$artikel) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound('Artikel tidak ditemukan');
        }

        $kategoriWithCount = [];
        foreach ($kategoris as $kg) {
            $count = $this->artikelModel->where('id_kategori', $kg['id_kategori'])->countAllResults();
            $kategoriWithCount[] = [
                'kategori' => $kg,
                'count' => $count
            ];
        }

        $data = [
            'kategori' => $kategori,
            'artikel' => $artikel,
            'allKategoris' => $kategoriWithCount
        ];

        return view('artikel/detail', $data);
    }
}

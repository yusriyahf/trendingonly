<?php

namespace App\Controllers;

use App\Models\ArtikelModel;
use App\Models\KategoriModel;
use CodeIgniter\Controller;

class Beranda extends BaseController
{
    protected $artikelModel;
    protected $kategoriModel;

    public function __construct()
    {
        $this->artikelModel = new ArtikelModel();
        $this->kategoriModel = new KategoriModel();
    }

    public function index()
    {
        $kategoris = $this->kategoriModel->findAll();
        $kategoriArtikel = [];
        $kategoriWithCount = [];

        // Get current time and calculate 4 hours ago
        $fourMinutesAgo = date('Y-m-d H:i:s');

        // Get latest articles published in last 4 hours with their categories
        $latestArticles = $this->artikelModel
            ->where('published_at >=', $fourMinutesAgo)
            ->orderBy('published_at', 'DESC')
            ->findAll(3); // Limit to 3 articles

        // Add category info to each article
        foreach ($latestArticles as &$article) {
            $article['kategori'] = $this->kategoriModel->find($article['id_kategori']);
        }

        foreach ($kategoris as $kategori) {
            $count = $this->artikelModel->where('id_kategori', $kategori['id_kategori'])->countAllResults();
            $kategoriWithCount[] = [
                'kategori' => $kategori,
                'count' => $count
            ];

            // Ambil lebih banyak artikel untuk kategori olahraga
            $limit = (strtolower($kategori['nama_kategori_id']) === 'olahraga') ? 6 : 3;
            $artikel = $this->artikelModel->getLatestByKategori($kategori['id_kategori'], $limit);

            $kategoriArtikel[] = [
                'kategori' => $kategori,
                'artikels' => $artikel
            ];
        }

        $data = [
            'kategoriArtikel' => $kategoriArtikel,
            'allKategoris' => $kategoriWithCount,
            'latestArticles' => $latestArticles
        ];

        return view('beranda', $data);
    }
}

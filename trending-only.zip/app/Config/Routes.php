<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
$routes->group('penulis', ['filter' => 'auth'], function ($routes) {
    $routes->group('artikel', function ($routes) {
        $routes->get('/', 'Penulis::index');
        $routes->get('create', 'Penulis::create');
        $routes->post('store', 'Penulis::store');
        $routes->get('edit/(:num)', 'Penulis::edit/$1');
        $routes->put('update/(:num)', 'Penulis::update/$1');
        $routes->delete('delete/(:num)', 'Penulis::delete/$1');
    });
});


$routes->get('/category', 'Home::category');
$routes->get('/contact', 'Home::contact');
$routes->get('/author', 'Home::author');
$routes->get('/about', 'Home::about');
$routes->get('/blog-post', 'Home::blog');


$routes->get('/', 'Beranda::index');
$routes->get('(:segment)', 'Artikel::kategori/$1');
$routes->get('(:segment)/(:segment)', 'Artikel::detail/$1/$2');



//penulis
